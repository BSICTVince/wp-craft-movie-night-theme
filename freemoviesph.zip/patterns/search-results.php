<?php
?>
<div class="content">
    <div class="inner-container">
        <div class="titles">
            <h1>Search</h1>
            <h2>results</h2>
        </div>
        <div class="item-container">
            <?php
            printf(
                esc_html__('Search Results for: %s', 'your-text-domain'),
                '<span>' . get_search_query() . '</span>'
            );
            ?>
            </h1>

            <?php if (have_posts()): ?>
                <div class="search-results-list">
                    <?php while (have_posts()):
                        the_post(); ?>
                        <article id="post-<?php the_ID(); ?>" 
                        <?php post_class('search-result-item'); ?>>
                            <h2 class="search-result-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            <div class="search-result-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <div class="pagination">
                    <?php
                    // Display pagination
                    the_posts_pagination(array(
                        'mid_size' => 2,
                        'prev_text' => __('&laquo; Previous', 'your-text-domain'),
                        'next_text' => __('Next &raquo;', 'your-text-domain'),
                    ));
                    ?>
                </div>
            <?php else: ?>
                <div class="no-results">
                    <h2><?php esc_html_e('No Results Found', 'your-text-domain'); ?></h2>
                    <p><?php esc_html_e('Sorry, but nothing matched your search terms. Please try again with different keywords.', 'your-text-domain'); ?>
                    </p>
                </div>
            <?php endif; ?>
        </div>
        <div class="load-more"><i class="fa fa-plus-circle more" aria-hidden="true"></i></div>
    </div>
</div>