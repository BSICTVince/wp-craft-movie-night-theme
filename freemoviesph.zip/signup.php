<?php
wp_head();
?>