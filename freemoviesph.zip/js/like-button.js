jQuery(document).ready(function($) {
    $('.like-button').on('click', function() {
        const button = $(this);
        const movieId = button.data('movie-id');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'like_movie',
                movie_id: movieId,
            },
            success: function(response) {
                if (response.success) {
                    button.text('Liked').attr('disabled', true);
                } else {
                    alert(response.data.message);
                }
            },
        });
    });
});
