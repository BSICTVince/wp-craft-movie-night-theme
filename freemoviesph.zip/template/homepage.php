<?php
/**
 * Template Name:  hp-template
 * Template Post Type: page
 * slug: homepage-template
 */
get_header();
?>

<h1>HOME PAGE</h1>


<?php get_footer(); ?>
